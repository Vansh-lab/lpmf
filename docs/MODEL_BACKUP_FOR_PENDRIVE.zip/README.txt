LPMF — Final Trained Model Backup
==================================

This is the LPMF project's final trained model, backed up on 2026-11-14.

File: lightgbm_model.txt
  - One multi-horizon LightGBM model (horizon is a feature, 96 blocks / 24h
    ahead, 37 features). Tuned with Optuna (25 trials on validation MAPE),
    early stopping on validation.
  - Test MAPE: 3.93% (96.07% accuracy) — see docs/MODEL_RESULTS.md for the
    full train/validation/test breakdown.

File: lightgbm_model.txt.sha256
  - SHA256 checksum of lightgbm_model.txt. To verify the file hasn't been
    corrupted or altered (e.g. after copying to a pen drive), run:
      Windows (PowerShell):  Get-FileHash lightgbm_model.txt -Algorithm SHA256
      Linux/Mac:             sha256sum -c lightgbm_model.txt.sha256
    The hash should read: 60f2c9f2a3757d9a50b0547e0db3503a65c2b20662f1bc81130f65e1a76b3dc9

Purpose: an offline, pen-drive copy of the exact model the dashboard and
report are built on, in case the live repo/laptop is unavailable on
submission or viva day.
